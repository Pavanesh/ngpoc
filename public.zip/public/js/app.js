angular.module('airline', [])
	.config(airlineRouter);

function airlineRouter ($routeProvider) {
	$routeProvider
		.when('/', {templateUrl: 'partials/destinations.html',
		 controller: function  ($scope) {
		 	$scope.setActive('destinations');
		 }})
		.when('/vehicles', {template: '<h3>Vehicles</h3>',
		 controller: function  ($scope) {
		 	$scope.setActive('vehicles');
		 }})
		.when('/reservations', {template: '<h3>Your Reservations</h3>',
		 controller: function  ($scope) {
		 	$scope.setActive('reservations');
		 }});
}