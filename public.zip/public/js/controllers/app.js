function AppCtrl ($scope) {
  $scope.setActive = function (type) {
    $scope.destinationsActive = '';
    $scope.vehiclesActive = '';
    $scope.reservationsActive = '';
	//alert(type);
    $scope[type + 'Active'] = 'active';		
	
	var helpExtension = ".html" ;
	var pageName = "help" + "/" + type + helpExtension;
	$scope.doHelp = function(){window.open(pageName, "tinyWindow", 'scrollbars=yes,menubar=no,height=600,width=600,resizable=yes,toolbar=no,location=no,status=no');
	}
	
}

  $scope.airports = {
    "STR": {
      "code": "STR",
      "name": "Stuttgart Airport",
      "city": "Stuttgart Airport",
      "destinations": [
        "ACE",
        "AMS"
      ],
	  "help": "Stuttgart Airport is an international airport located approximately 13 km south of Stuttgart, Germany."
    },
    "FRA": {
      "code": "FRA",
      "name": "Frankfurt am Main International Airport",
      "city": "Frankfurt-am-Main",
      "destinations": [
        "ACC",
        "ALA"
      ],
	  "help":"Frankfurt Airport is a major international airport located in Frankfurt, Germany. Run by transport company Fraport, Frankfurt Airport is by far the busiest airport by passenger traffic in Germany,"
    },
    "SXF": {
      "code": "SXF",
      "name": "Berlin-Sch�nefeld International Airport",
      "city": "Kansas City",
      "destinations": [
        "AAL",
        "AGA"
      ],
	  "help" : "Berlin Sch�nefeld Airport is an international airport located near the town of Sch�nefeld in Brandenburg, directly at the southern border of Berlin and 18 km southeast of the city centre"
    }
  };
  $scope.sidebarURL = 'partials/airport.html';
  $scope.currentAirport = null;

  $scope.setAirport = function (code) {
	//alert($scope.airports[code].name);
    $scope.currentAirport = $scope.airports[code];
  };
}